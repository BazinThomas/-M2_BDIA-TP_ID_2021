# Pour compiler le projet
sbt clean compile

# Pour exécuter le projet
sbt run


